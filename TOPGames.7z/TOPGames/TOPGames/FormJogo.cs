﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TOPGames
{
    public partial class FormJogo : Form
    {
        public FormJogo()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpaCampos_Click(object sender, EventArgs e)
        {
            txtId.Text = "";
            txtNome.Text = "";
            txtQuantidade.Text = "";
            txtValor.Text = "";
        }

        private void FormJogo_Load(object sender, EventArgs e)
        {
            Jogo jog = new Jogo();
            List<Jogo> jogos = jog.listajogo();
            dgvJogo.DataSource = jogos;
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                int qtde = Int32.Parse(txtQuantidade.Text);
                Jogo jogo = new Jogo();
                jogo.Inserir(txtNome.Text, qtde, Convert.ToDecimal(txtValor.Text));
                MessageBox.Show("Jogo cadastrado com sucesso!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Jogo> jog = jogo.listajogo();
                dgvJogo.DataSource = jog;
                txtId.Text = "";
                txtNome.Text = "";
                txtQuantidade.Text = "";
                txtValor.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Int32.Parse(txtId.Text);
                int qtde = Int32.Parse(txtQuantidade.Text);
                Jogo jogo = new Jogo();
                jogo.Atualizar(id, txtNome.Text, qtde, Convert.ToDecimal(txtValor.Text));
                MessageBox.Show("Jogo atualizado com sucesso!", "Atualização", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Jogo> pro = jogo.listajogo();
                dgvJogo.DataSource = pro;
                txtId.Text = "";
                txtNome.Text = "";
                txtQuantidade.Text = "";
                txtValor.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Int32.Parse(txtId.Text);
                Jogo jogo = new Jogo();
                jogo.Exclui(id);
                MessageBox.Show("Jogo excluído com sucesso!", "Exclusão", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Jogo> pro = jogo.listajogo();
                dgvJogo.DataSource = pro;
                txtId.Text = "";
                txtNome.Text = "";
                txtQuantidade.Text = "";
                txtValor.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Int32.Parse(txtId.Text);
                Jogo jogo = new Jogo();
                jogo.Localiza(id);
                txtNome.Text = jogo.Nome;
                txtQuantidade.Text = Convert.ToString(jogo.Quantidade);
                txtValor.Text = Convert.ToString(jogo.Valor);
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void txtNome_Leave(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\TOPGames\\TOPGames\\DB.mdf;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("SELECT nome FROM Jogo WHERE nome=@nome", con);
            cmd.Parameters.AddWithValue("@nome", SqlDbType.NChar).Value = txtNome.Text;
            cmd.CommandType = CommandType.Text;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            int ctr = 0;
            while (dr.Read())
            {
                ctr++;
            }
            if (ctr == 1)
            {
                MessageBox.Show("Este Jogo já existe em nossa base de dados!", "Registro repetido!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtNome.Text = "";
                txtNome.Focus();
                con.Close();
            }
            else
            {

            }
        }

        private void dgvJogo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = this.dgvJogo.Rows[e.RowIndex];
            txtId.Text = row.Cells[0].Value.ToString();
            txtNome.Text = row.Cells[1].Value.ToString();
            txtQuantidade.Text = row.Cells[2].Value.ToString();
            txtValor.Text = row.Cells[3].Value.ToString();
        }
    }
}
