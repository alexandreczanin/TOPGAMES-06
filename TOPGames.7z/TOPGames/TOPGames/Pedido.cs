﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace TOPGames
{
    class Pedido
    {
        public int ID { get; set; }
        public string Situação { get; set; }

        public List<Pedido> listapedido()
        {
            List<Pedido> li = new List<Pedido>();
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM Pedido";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Pedido u = new Pedido();
                u.ID = (int)dr["Id"];
                u.Situação = dr["situacao"].ToString();
                li.Add(u);
            }
            return li;
        }
    }
}