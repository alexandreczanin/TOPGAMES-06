﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace TOPGames
{
    class Cliente
    {
        public int ID { get; set; }
        public string Nome { get; set; }
        public string Celular { get; set; }
        public DateTime Data_Nascimento { get; set; }
        public string CEP { get; set; }
        public string Endereço { get; set; }
        public string Número { get; set; }
        public string Cidade { get; set; }
        public string Bairro { get; set; }

        public List<Cliente> listacliente()
        {
            List<Cliente> li = new List<Cliente>();
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM Cliente";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Cliente c = new Cliente();
                c.ID = (int)dr["Id"];
                c.Nome = dr["nome"].ToString();
                c.Celular = dr["celular"].ToString();
                c.Data_Nascimento = Convert.ToDateTime(dr["dt_nascimento"]);
                c.CEP = dr["cep"].ToString();
                c.Endereço = dr["endereco"].ToString();
                c.Número = dr["numero"].ToString();
                c.Cidade = dr["cidade"].ToString();
                c.Bairro = dr["bairro"].ToString();
                li.Add(c);
            }
            return li;
        }
        public void Inserir(string nome, string celular, DateTime dt_nascimento, string cep, string endereco, string numero, string cidade, string bairro)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "INSERT INTO Cliente(nome,celular,dt_nascimento,cep,endereco,numero,cidade,bairro) VALUES ('" + nome + "','" + celular + "',Convert(DateTime,'" + dt_nascimento + "',103),'" + cep + "','" + endereco + "','" + numero + "','" + cidade + "','" + bairro + "')";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            ClassConecta.FecharConexao();
        }

        public void Localiza(int id)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM Cliente WHERE Id='" + id + "'";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Nome = dr["nome"].ToString();
                Celular = dr["celular"].ToString();
                Data_Nascimento = Convert.ToDateTime(dr["dt_nascimento"]);
                CEP = dr["cep"].ToString();
                Endereço = dr["endereco"].ToString();
                Número = dr["numero"].ToString();
                Cidade = dr["bairro"].ToString();
                Bairro = dr["bairro"].ToString();
            }
        }

        public void Atualizar(int id, string nome, string celular, DateTime dt_nascimento, string cep, string endereco, string numero, string cidade, string bairro)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "UPDATE Cliente SET nome='" + nome + "',celular='" + celular + "',dt_nascimento=Convert(DateTime,'" + dt_nascimento + "',103),cep='" + cep + "',endereco='" + endereco + "',numero='" + numero + "',cidade='" + cidade + "',bairro='" + bairro + "' WHERE Id = '" + id + "'";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            ClassConecta.FecharConexao();
        }

        public void Exclui(int id)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "DELETE FROM Cliente WHERE Id='" + id + "'";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            ClassConecta.FecharConexao();
        }
    }
}
